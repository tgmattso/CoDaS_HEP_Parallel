//
// This simple program will cover enough of the C programming
// language for you to do the exercises in our OpenMP tutorial.
//
// As you've probably figured out, the two slashes indicate a 
// comment.  I can also do a comment this way:
//
// you run this through a compiler
//
//        gcc LearningC.c
//
// then run the program by giving the name of the output file 
// (default a.out)
//
//       ./a.out

/* this is a comment */

// You can insert a file into your program source code with
// an include statement.  Where you do this all the time
// is to tell the program to include the interfaces to all
// the functions and types needed for input/out

#include<stdio.h>

//
// there are other satements that start with a hash.   These 
// are all statements processed at compile-time by a pre
// processor.  Here is one used quite a bit

#define Nvalue 5

// This will take everywhere you see an Nvalue in the program 
// and replace it with 5.  This is done before compilation.
// We typically do this for any constants you want to appear
// in a program.

// A variable gives a name to a region of memory.  You have to
// declare variables before you use them.  For example, you
// can define a whole number (int) or a floating point 
// number (float) or a floating point number that has more
// bits (double)

int whole = 5;
float f = 3.4;
double d = 7.8;  // I can put a comment on the rest of the line

// Notice how every statement ends with a semicolon.  This is 
// through the language so you get used to typing lots of 
// semicolons.

// Your program consists of a bunch of functions.  We will define
// some functions later, but for now you need to tell the compiler
// to expect the function we'll define later

int dumbFunc(int);

// The program always starts at the main function.   You define 
// its return value which is basically an int

int main()
{

// C is a block structured language.  You start a block with an
// open bracket { and later we close the block with a close
// bracket }

// we can declare variables that we will later us

int   j,    k;
float newf, newd;

// here is how you print something.  notice that I specify 
// the format

printf(" my int is %d and my float is %f, and my double is %lf",
        whole, f, d);

// and I can output a newline character

printf(" \n");

// of course, I do all this at once

printf(" my int is %d and my float is %f, and my double is %lf\n",
        whole, f, d);

//  You can do arithmetic

newf = f + f; // of course there is - * / and other weird ones 
printf(" my new f is %f \n",newf);

// and you can play with loops

for(k=0; k<Nvalue; k++)  // the ++ says increment the variable
{
   printf(" k = %d ",k);
}
printf("\n");

// And I can call fuctions pretty much just as you'd expect.
// remember, I had to tell the compiler earlier to expect this
// function and I must define it either in this file or 
// in another file I pass to the compiler.

j = dumbFunc(Nvalue);
printf(" My function returned the value %d \n",j);

// and when we are done we return the value generated
// by this function (which in this case is main)

return j;

}

int dumbFunc(int val)
{

// here is an array that I declare statically

float arr[Nvalue];
float sum = 0; // I can initialize a variable when I declare it

int i; // this i is inside the block that is the function.  It is
       // not the same "i" as the "i" in main

for(i=0;i<Nvalue;i++) arr[i] = (float)i; // see how I turned i
                                          // into a float? This is 
                                          // cast.

for(i=0; i<Nvalue;i++){sum += arr[i];}   // see the nice short hand
                                          // notation for:
                                          // sum = sum + arr[i]
     
return (int)sum;  // return my value but the type has to match that
                  // defined for the function.  So I cast sum to an int

}  // and I need to close the block of statements that make up
   // the function.
