double random();
void seed(double low_in, double hi_in);

